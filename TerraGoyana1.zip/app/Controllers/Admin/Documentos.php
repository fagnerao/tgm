<?php namespace App\Controllers\Admin;

use CodeIgniter\Controller;


class Documentos extends Controller{
    
    protected $helpers = ['auth','Funcoes','text'];
  
    public function index() {
        
            $freeToGO = pageAutorize(65);
            if(!$freeToGO){
                setMsg('msg', 'Você não possui acesso a essa página','erro');
               return redirect()->to(base_url().'/admin/painel'); 
            }

        

        $model = new \App\Models\Admin\Documentos_model();
        $data = ['documentos' => $model->getDados(),
                 'title' => 'Lista de Documentos',
        ];
    

         if(empty($data)){
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Erro na consulta');
        }
        
        
        return view('admin/documentos/index', $data);

    }


    public function create($id=NULL) {
        
        $freeToGO = pageAutorize(65);
        if(!$freeToGO){
            setMsg('msg', 'Você não possui acesso a essa página','erro');
           return redirect()->to(base_url().'/admin/painel'); 
        }

        $model = new \App\Models\Admin\Documentos_model();
        $data = [
            'documento' => $model->doCreate($id),
            'title'    => "Editar/Criar Documento",
        ];
          
        return view('admin/documentos/modulo' ,$data);
      
    }


    public function core() {
        
        $freeToGO = pageAutorize(65);
        if(!$freeToGO){
            setMsg('msg', 'Você não possui acesso a essa página','erro');
           return redirect()->to(base_url().'/admin/painel'); 
        }

        $model = new \App\Models\Admin\Documentos_model();
        $rules=['titulo' => 'required' ];
      
        if ($this->validate($rules)){
            $dados_salvar['id']           = $this->request->getVar('id');
            $dados_salvar['id_dep']       = $this->request->getVar('id_dep');
            $dados_salvar['titulo']       = $this->request->getVar('titulo');

            $model->save($dados_salvar);
           
        }
        else {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Erro na inserção');    
        }
        setMsg('msg', 'Registro atualizado com sucesso','sucesso');
    
        return redirect()->to(base_url().'/admin/documentos'); 

    }


    public function arquivos($id=NULL) {
        
        $freeToGO = pageAutorize(65);
        if(!$freeToGO){
           setMsg('msg', 'Você não possui acesso a essa página','erro');
           return redirect()->to(base_url().'/admin/painel'); 
        }
        $id  = $this->request->getVar('id');

        $model_doc = new \App\Models\Admin\Documentos_model();
        $model_arq = new \App\Models\Admin\Arquivos_model();

        $data = [
            'documento' => $model_doc->getDados($id),
            'arquivos'  => $model_arq->getDados($id),
            'title'    => "Enviar Arquivos",
        ];
          
        // echo'<pre>';
        // print_r($data['arquivos']);
        // echo'</pre>';exit;
        return view('admin/documentos/arquivos' ,$data);
      
    }

    public function upload() {
        
        $freeToGO = pageAutorize(65);
        if(!$freeToGO){
            setMsg('msg', 'Você não possui acesso a essa página','erro');
           return redirect()->to(base_url().'/admin/painel'); 
        }

        $model = new \App\Models\Admin\Arquivos_model();
        $rules=['titulo' => 'required' ];
        
        $file  = $this->request->getFile('imagem');

        $nome = NULL;
        if (isset($file)){
            if ($file->isValid() && ! $file->hasMoved())
            {
                  $nome = $file->getRandomName();
                  $file->move('uploads/documentos', $nome);
                 
                };
        }
       
        $id_doc = $this->request->getVar('id_doc');
      
        if ($this->validate($rules)){
            $dados_salvar['id']      = $this->request->getVar('id');
            $dados_salvar['id_doc']  = $id_doc;
            $dados_salvar['id_user'] = $this->request->getVar('id_user');
            $dados_salvar['titulo']  = $this->request->getVar('titulo');

            if(isset($nome)){
                $dados_salvar['file'] = $nome;
            }
           
            $model->save($dados_salvar);
           
        }
        else {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Erro no cadastro do arquivo');    
        }
        setMsg('msg','Registro atualizado' , 'sucesso');
    
        return redirect()->to(base_url().'/admin/documentos/arquivos/'.$id_doc); 

    }

    public function del($id=NULL) {
        $freeToGO = pageAutorize(65);
            if(!$freeToGO){
                setMsg('msg', 'Você não possui acesso a essa página','erro');
               return redirect()->to(base_url().'/admin/painel'); 
            }

        if ($this->request->isAJAX()) {
            $id = service('request')->getPost('id');
        } 
        $db      = \Config\Database::connect();
        $builder = $db->table('int_documentos');
        
        if ($builder->delete(['id' => $id])){
            echo json_encode( TRUE );
        }
        else echo json_encode( FALSE );

    }


    public function delArquivo($id=NULL) {
        $freeToGO = pageAutorize(65);
            if(!$freeToGO){
                setMsg('msg', 'Você não possui acesso a essa página','erro');
               return redirect()->to(base_url().'/admin/painel'); 
            }

        if ($this->request->isAJAX()) {
            $id = service('request')->getPost('id');
        } 
        $db      = \Config\Database::connect();
        $builder = $db->table('int_arquivos');
        
        if ($builder->delete(['id' => $id])){
            echo json_encode( TRUE );
        }
        else echo json_encode( FALSE );

    }
}


