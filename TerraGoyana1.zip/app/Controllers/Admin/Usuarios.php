<?php namespace App\Controllers\Admin;

use CodeIgniter\Controller;


class Usuarios extends Controller{

    protected $helpers = ['auth','Funcoes', 'form'];

    public function index()    {

        $freeToGO = pageAutorize(1);
        if(!$freeToGO){
           setMsg('msg', 'Você não possui acesso a essa página','erro');
           return redirect()->to(base_url().'/admin/painel'); 
        }

        $model = new \App\Models\Admin\Usuarios_model();

        $session = session();  
        $id = $session->get('id'); 

        $data['title']    = "Listagem de Usuarios";
        $data['usuarios'] = $model->getDados();
       
        return view('admin/usuarios/index', $data);
        
    }


    public function create($id=NULL) {

        $freeToGO = pageAutorize(1);
        if(!$freeToGO){
           setMsg('msg', 'Você não possui acesso a essa página','erro');
           return redirect()->to(base_url().'/admin/painel'); 
        }

        $model = new \App\Models\Admin\Usuarios_model();
        $data['title']    = "Editar Usuario";
        $data['usuario']  = $model->getDados($id);
        $data['groups']   = $model->getGroups();
    
        return view('admin/usuarios/modulo' ,$data);
       
    }



    public function core() {

        $freeToGO = pageAutorize(1);
            if(!$freeToGO){
               setMsg('msg', 'Você não possui acesso a essa página','erro');
               return redirect()->to(base_url().'/admin/painel'); 
            }

            if(!empty($this->request->getVar('password'))) {
                $rules = [
                    'name'          => 'required|min_length[2]|max_length[50]',
                    'password'      => 'required|min_length[4]|max_length[50]',
                    'confirm_password'     => 'matches[password]',
                ];
            }else{
                
                $rules = [ 'name'  => 'required|min_length[2]|max_length[50]'];
            }
       
          
        $id = $this->request->getVar('id');

        if($this->validate($rules)){
            
            $model = new \App\Models\Admin\Usuarios_model();
            

            if(!empty($password)) {
                $dataUser['password']= password_hash($this->request->getVar('password'), PASSWORD_DEFAULT);
            }

            $dataUser = [
                'id'         => $this->request->getVar('id'),
                'name'       => $this->request->getVar('name'),
                'nascimento' => $this->request->getVar('nascimento'),
            ];

            $group = array_sum($this->request->getVar('group'));
           
            $model->save($dataUser);

                     
            $db = \Config\Database::connect();
            $db = db_connect();
            $db->query("UPDATE `vz_usersgroup` SET `id_group`=".$group." WHERE `id_user`=".$id."");

          
            setMsg('msg','Registro atualizado' , 'sucesso');
            return redirect()->to(base_url().'/admin/usuarios/create/'.$id); 

        }else{
            setMsg('msg','Os dados não foram validados' , 'erro');
            return redirect()->to(base_url().'/admin/usuarios/create/'.$id); 
        }
          
    
    }

}