<?php 
namespace App\Controllers\Front;
use CodeIgniter\Controller;
use App\Models\Front\siteConfig_model;
use App\Models\Front\Banners_model;
use App\Models\Front\Pagina_model;


class Home extends Controller
{
    protected $helpers = ['auth','Funcoes','text'];
   
	public function index()
	{
        
 		$model            = new siteConfig_model();
 		$model_banner     = new Banners_model();
 		$model_pagina     = new Pagina_model();

        $data = [
            'dados'       => $model->getDados(),
            'menu'        => $model->getLinks(),
            'noticias'    => $model_pagina->getNews(2,4,'desc'),
            'comunicados' => $model_pagina->getComunicados(8,4,'desc'),
            'sobre'       => $model_pagina->getTexto(175),
        ];
       
        return view('front/intranet/content', $data);
		
	}

    //--------------------------------------------------------------------
	
    public function contato()
	{
        $model            = new siteConfig_model();
        $model_banner     = new Banners_model();
        $model_pagina     = new Pagina_model();

       $data = [
           'dados'        => $model->getDados(),
           'banners'      => $model_banner->getDados('3'),
           'popup'        => $model_banner->getDados('2'),
           'menu'         => $model->getLinks(),
           'galeria'      => $model_pagina->getTexto(100),
           'sobre'        => $model_pagina->getTexto(99),
       ];
     
        return view('front/contato/index', $data);
		
    }
    public function curriculo()
	{
        helper('text','Funcoes');
        $model            = new siteConfig_model();
        $model_pagina      = new Pagina_model();

       $data = [
            'dados'    => $model->getDados(),
            'noticias' => $model_pagina->getNews(6,5,'asc'),
            'servicos' => $model_pagina->getNews(7,10,'asc'),
       ];
     
        return view('front/site/curriculo', $data);
		
    }
    
    public function enviarCurriculo() {
       
        $model = new \App\Models\Categorias_model();
        $rules=['nome' => 'required' ];
        $img  = $this->request->getFile('imagem');

        $nome = NULL;
        if (isset($img)){
            if ($img->isValid() && ! $img->hasMoved())
            {
                  $nome = $img->getRandomName();
                  $img->move('uploads/curriculos', $nome);
                 
                };
        }
       
        if ($this->validate($rules)){
            $dados_salvar['nome']     = $this->request->getVar('nome');
            $dados_salvar['email']    = $this->request->getVar('email');
            $dados_salvar['fone']     = $this->request->getVar('fone');
            $dados_salvar['curriculo'] = $nome;
          
            $db      = \Config\Database::connect();
            $builder = $db->table('curriculo');
            $builder->insert($dados_salvar);
           
        }
        else {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Erro ao enviar.');    
        }

        $session = session();
        $session->setFlashdata('msg', 'Seu currículo foi envaido com sucesso !', 'sucesso');
    
        return redirect()->to(base_url().'/curriculo'); 

    }
	
	//--------------------------------------------------------------------
	
	
 public function sendEmail(){
   
            if ($this->request->isAJAX()) {
            $nome = service('request')->getPost('nome');
            $email = service('request')->getPost('email');
            $fone = service('request')->getPost('fone');
            $para = 'escritoriocentralgsia@hotmail.com';
            $mensagem = service('request')->getPost('mensagem');
           
       
        $de   =  $email;
       
      
        $mailContent = '
            <h2>Email de Contato enviado pelo Site</h2>
            <p>Fone: '.$fone.'</p>
            <p>'.$mensagem.'</p>
        ';

		$email = \Config\Services::email();

		$email->setFrom($de, $nome);
		$email->setTo($para);
		$email->setSubject('Mensagem enviada pelo Site');
		$email->setMessage($mailContent);
       
        $send = $email->send();
        $email->printDebugger(['headers']);
		
		 if($send){
                $retorno = [
                    'erro' => 0,
                    'msg'  => 'Mensagem enviada com sucesso'
                    ];
                    
                }
        else {
            $retorno = [
                    'erro' => 1,
                    'msg'  => 'Erro ao enviar email'
                    ];
                    
        }
            }else{
                $retorno = [
                    'erro' => 1,
                    'msg'  => 'Erro ao enviar email'
                    ];
            }
		echo json_encode($retorno);
		exit;

    }



}