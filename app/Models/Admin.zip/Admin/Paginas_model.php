<?php 
namespace App\Models\Admin;

use CodeIgniter\Model;

class Paginas_model extends Model{

    protected $table      = 'paginas';
    protected $primaryKey = 'id';
    protected $returnType = 'object';
    protected $allowedFields = ['id','titulo','texto','slug','imagem','ativo','data','id_categoria'];
   

    public function getDados($id=NULL) {

        if($id===NULL){
            return $this->findAll();
        }
        return $this->asObject()->where(['id'=>$id])->first();
    }

    public function doCreate($id=NULL) {
  
        return $this->asObject()->where(['id'=>$id])->first();

    }

    public function getFotosGalerias($id=NULL){
        if ($id) {
            
            return $this->db->table('galerias')
            ->where('id_pagina', $id)
            ->get()->getResultObject();        
        }
    }



   
}

