<?php 
namespace App\Models\Admin\Shop;

use CodeIgniter\Model;

class Atributos_model extends Model{
    protected $table      = 'shop_atributos';
    protected $returnType = 'object';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id','id_produto','cor','imagem','tamanho','quantidade','ativo'];
   

    public function getDados($id=NULL) {

        if($id===NULL){
            return $this->findAll();
        }
        return $this->where('id',$id)->first();
    }

    public function doCreate($id=NULL) {
  
        return $this->where(['id'=>$id])->first();

    }
    public function getAtributos($id=NULL) {
  
        return $this->where(['id_produto'=>$id])->findAll();

    }
    
}

