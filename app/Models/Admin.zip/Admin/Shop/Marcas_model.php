<?php 
namespace App\Models\Admin\Shop;

use CodeIgniter\Model;

class Marcas_model extends Model{
    protected $table      = 'shop_marcas';
    protected $returnType = 'object';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id','id_pai','nome','slug','ativo'];
   

    public function getDados($id=NULL) {

        if($id===NULL){
            return $this->asObject()->findAll();
        }
        return $this->where('id',$id)->first();
    }

    public function doCreate($id=NULL) {
  
        return $this->where(['id'=>$id])->first();

    }

    
}

