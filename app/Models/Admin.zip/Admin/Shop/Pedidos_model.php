<?php 
namespace App\Models\Admin\Shop;

use CodeIgniter\Model;

class Pedidos_model extends Model{
    protected $table      = 'shop_pedidos';
    protected $returnType = 'object';
    protected $primaryKey = 'id';
    protected $allowedFields = [
                            'id',
                            'id_cliente',
                            'transacao',
                            'referencia',
                            'tipo_pagamento',
                            'boleto',
                            'total_produto',
                            'total_frete',
                            'total_pedido',
                            'data_cadastro',
                            'cod_rastreio',
                            'autorizacao',
                            'endereco',
                            'status'];
   

    public function getDados($id=NULL) {

        if($id===NULL){
            return $this->db->table('shop_pedidos')
            ->select('shop_pedidos.*, users.nome,users.cpf, users.fone,')
            ->join('users', 'users.id = shop_pedidos.id_cliente','left')
            ->orderBy('shop_pedidos.transacao','DESC')
            ->get()->getResultObject();
        }
        else{
        return $this->db->table('shop_pedidos')
        ->select('shop_pedidos.*, users.nome,users.cpf, users.fone')
        ->join('users', 'users.id = shop_pedidos.id_cliente')
        ->where('users.id',$id)
        ->get()->getResultObject();

        }
    }
                        
    
    public function getDadosPedido($id=NULL) {
      
            return $this->db->table('shop_pedidos')
            ->select('shop_pedidos.*, users.nome,users.cpf, users.fone')
            ->join('users', 'users.id = shop_pedidos.id_cliente','left')
            ->where('shop_pedidos.id',$id)
            ->get()->getResultObject();
       
    }
       
   
    public function getAtributo($id=NULL) {
        return $this->db->table('shop_atributos')
        ->where('id',$id)
        ->get()->getResultObject();
     }

    public function getItens($id=NULL) {
        return $this->db->table('shop_pedidos_itens')
        ->select('shop_pedidos_itens.*, shop_produtos.nome')
        ->join('shop_produtos', 'shop_produtos.id = shop_pedidos_itens.id_produto','left')
        ->where('shop_pedidos_itens.id_pedido',$id)
        ->get()->getResultObject();
     }

    
}

