<?php 
namespace App\Models\Admin\Shop;

use CodeIgniter\Model;

class Produtos_model extends Model{
    protected $table      = 'shop_produtos';
    protected $returnType = 'object';
    protected $primaryKey = 'id';
    protected $allowedFields = [    	
        'id',
        'id_marca',
        'id_categoria',
        'nome',
        'codigo',
        'valor',
        'valor_sd',
        'destaque',
        'ativo',
        'peso',
        'altura',
        'largura',
        'comprimento',
        'informacao',
        'meta_link',
        'meta_descricao',
        'created_at',
        'updated_at',
        'slug',
        'deleted_at'];

    public function getDados($id=NULL) {

        if($id===NULL){
            return $this->db->table('shop_produtos')
            ->select('shop_produtos.*, shop_marcas.nome as marca,shop_categorias.nome as categoria')
            ->join('shop_marcas', 'shop_marcas.id = shop_produtos.id_marca','left')
            ->join('shop_categorias', 'shop_categorias.id = shop_produtos.id_categoria','left')
            ->get()->getResultObject();
        }
        else{
            return $this->db->table('shop_produtos')
            ->select('shop_produtos.*, shop_marcas.nome as marca,shop_categorias.nome as categoria')
            ->join('shop_marcas', 'shop_marcas.id = shop_produtos.id_marca','left')
            ->join('shop_categorias', 'shop_categorias.id = shop_produtos.id_categoria','left')
            ->where('produtos.id',$id)
            ->get()->getResultObject();
       
        }
    }

   
    public function getCatPai($id=NULL) {
        return $this->where(['id'=>$id])->first();
    }

    public function doCreate($id=NULL) {
        return $this->asObject()->where(['id'=>$id])->first();
       
    }

    public function getProdutoId($id=NULL){
        if($id===NULL){
            return $this->db->table('shop_produtos')
            ->select('id,nome')
            ->get()->getResultObject();
        }
        else{
        return $this->db->table('shop_produtos')
        ->select('id,nome')
        ->where('id',$id)
        ->get()->getResultObject();
        }
       
    } 

    public function getLastid(){
        return $this->select('id')
        ->orderBy('id','desc')
        ->limit(1)
        ->get()->getResultObject();   

    }

    public function getFotosGalerias($id=NULL){
        if ($id) {
            return $this->db->table('galerias')
            ->where('id_pagina', $id)
            ->get()->getResultObject();        
        }
    }
    
}

