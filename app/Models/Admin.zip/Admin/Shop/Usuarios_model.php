<?php 
namespace App\Models\Admin\Shop;

use CodeIgniter\Model;

class Usuarios_model extends Model{
    protected $table      = 'users';
    protected $returnType = 'object';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id','nome','email','cpf','fone','percentual'];
   

    public function getDados($id=NULL) {

        if($id===NULL){
            return $this->findAll();
        }
        return $this->where('id',$id)->first();
    }

    public function doCreate($id=NULL) {
  
        return $this->where(['id'=>$id])->first();

    }
    public function getAtributos($id=NULL) {
  
        return $this->where(['id_produto'=>$id])->findAll();

    }
    
}

