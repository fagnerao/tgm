<?php

return [
	'noFilter'           => 'O filtro \'{0}\' deve ter um alias correspondente definido.',
	'incorrectInterface' => '{0}deve implementar CodeIgniter\Filters\FilterInterface.',
];
