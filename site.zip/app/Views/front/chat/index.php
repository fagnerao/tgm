<?= $this->extend('front/intranet/index.php') ?>
<?= $this->section('content') ?>
<?php echo view('front/chat/chat') ?>
<?= $this->endSection('content') ?>